const hello = 'Hello world!';

let main = () => {
    console.log(hello);
};

main();