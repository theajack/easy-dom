module.exports = {
    target: [
        'npm',
        'tnpm',
    ],
    tpl: [
        'README.md',
        'LICENSE'
    ]
};