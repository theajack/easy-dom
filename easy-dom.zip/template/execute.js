const render = require('./render/render');

render();
// const path = require('path');

// const fs = require('fs');
// let a = fs.readFileSync(path.resolve('./template', 'a.js'), {encoding: 'utf-8'});
// console.log(a);