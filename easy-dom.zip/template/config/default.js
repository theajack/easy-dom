module.exports = {
    data: {
        // template
        'README.md': {
            head: '[返回主页](https://git.code.oa.com/cros-cloudgame/js-sdk/wikis/%E4%BA%91%E6%B8%B8%E6%88%8F%20JS%20SDK%20%E7%9B%B8%E5%85%B3%E6%96%87%E6%A1%A3)',
            gitRepo: 'http://tnpm.oa.com/package/@tencent/easy-dom',
            intro: '开发 [gmcg-sdk](https://git.code.oa.com/cros-cloudgame/js-sdk) 时开发的操作dom的库',
            npm: 'tnpm',
            install: '@tencent/easy-dom',
            script: 'https://cdn-go.cn/cros-cloudgame/js-sdk/latest/easydom.min.js',
        },
        'LICENSE': {
            author: 'tackchen'
        }
    },
    output: './template/config'
};

/**
 * output: 'xxx',
 * output: ['','','']
 * output: {a:'',b:''}
 * output: {a:['','',''],b:''}
 */